### Adding Rooms script to frontend:

- Copy both `js` files in public folder. 
- Copy the below inside `<head/>` tag of index.html.
```html
<script src="socket.io.js"></script>
<script src="rooms.js"></script>
```
- Now you have `Rooms` script available globaly inside `window`.


### Usage:
- Start the backend server.
- Call `Rooms.init()` on application mount with loggedin user details to initialize rooms server.
```js
Rooms.init({ id, name, email }, serverUrl);
```
- Join a user inside a room.
```js
Rooms.join(roomName, { id, name, email });
```
- Send a message after joining a room.
```js
Rooms.sendMessage(message);
```
- Attach Listeners to receive realtime data from rooms server.
```js
// You can attach listeners after init() is called.
Rooms.addListener('message', (message) => {
  console.log('recieved message in room', message);
});
```


### See
- `rooms.js` for script implementation.
- Run index.html for demo.